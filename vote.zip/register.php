<?php
include("connect.php");

?>

<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>Register | Futa </title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" type="text/css" media="screen" href="main.css" />
    <script src="main.js"></script>
</head>
<body>
<br>

    <div id="banner-reg">
        <div class="header">
       <div id="logo">
       <img style="float:left;height:100px;width:130px;margin-left:130px; margin-top:7px; border-radius:10px;" src="futo.jpg">
       </div>
       <div class="head">
       <h1>FEDERAL UNIVERSITY OF TECHNOLOGY AKURE </h1>
       </div>

            
        </div>
    <table>
        <tr>
            <td >
                <div class="content">
              
               <h1>Welcome to FUTA online voting registration portal</h1>
               
                 <h2>  Please ensure you register in order for you to be qualified to vote for your favorite candidate</h2>

</div>
     </td>
            <td>
               <h3 style="text-align:center; color:white;">Already have a Voters account sign-in</h3>
                <div id="reg-form">
                    <br>
                    <br> <br> 
                    <form method="post" action="register.php">
                        <label class="label-reg">FirstName: </label>
                    <input type="text" name="Firstname" class="type-input" placeholder="Enter your firstname" required /><br><br> 
                    <label class="label-reg">LastName: </label>
                    <input type="text" name="Lastname" class="type-input" placeholder="Enter your lastname" required /><br><br>
                    <label class="label-reg">MatricNo: </label>
                    <input type="text" name="Matricno" class="type-input" placeholder="Enter your matric number" required /><br><br>
                    <label class="label-reg">Department: </label>
                    <input type="text" name="Department" class="type-input" placeholder="Enter your department" required /><br><br>
                    <label class="label-reg">Password: </label>
                    <input type="password" name="password" class="type-input" placeholder="Enter your password" required /><br><br>
                    <input type="submit" class="submit-reg" name="submit" value="Register" />
                    <h3 style="color:red"> <i> already have an account please <a href="index.php">Login</a></i> </h3>

                </div>
            </td>
</tr>
</table>

<br><br><br>
<div class="footer">
           
   </div>

    </div>

<?php
if(isset($_POST['submit']))
{
    $Firstname = $_POST['Firstname'];
    $Lastname = $_POST['Lastname'];
    $Matricno = $_POST['Matricno'];
    $Department = $_POST['Department'];
    $Password = $_POST['password'];
    
    $sql = "INSERT INTO voters_account (Firstname,Lastname,Matricno,Department,password) VALUES ('$Firstname','$Lastname','$Matricno','$Department','$Password')";
    $result = mysqli_query($conn, $sql);
    if($result)
    {
        if(mysqli_affected_rows($conn)>0)
        {
            echo "<h2> Registration successful, Please go back to login page to sign into your account</h2>";
        }
        else{
            echo ("Error in registration");
        }
    }
}



?>


</body>
</html>