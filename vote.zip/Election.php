<?php
session_start();
include("connect.php");
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>Election Page | FUTA</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" type="text/css" media="screen" href="main.css" />
    <script src="main.js"></script>
</head>
<body>
<?php echo 'Welcome'  .$_SESSION['Matricno'] ?>

<div id="voter-banner">
<div class="voter-header">
       <div id="voter-logo">
       <img style="float:left;height:90px;width:100px; margin-top:17px; border-radius:10px;" src="futo.jpg">
       </div>
       <div class="headings">
       <h3>FEDERAL UNIVERSITY OF TECHNOLOGY AKURE  </h3>
       </div>
       
       <br><br> <br><br>    
         
  <br><br>
<table width="1000">
    <tr>
        <td>
     <!-- form for selecting candidate for the election ############################### -->
     <h2> Welcome to FUTA online voting platform</h2>
     <h2>Please select the position in order to choose 
     the candidate of your choice for that position </h2>
</td>
<td style="background-color:purple; height:408px;width:610px;border-radius:4 px;">
<div class="vote">
<form method="post" action="vote.php">
    <br>
    <h2>Select position to see the list of candidates available </h2>
    <br>
    <label>POSITION</label>
    <select style="padding:7px;width:170px;border-radius:4px;" name="position">
    <option></option>
    <option value="president">PRESIDENT</option>
    <option value="vice president">VICE PRESIDENT</option>
    <option value="secretary">SECRETARY</option>
    <option value="pro">P.R.O</option>
    <option value="welfare">WELFARE</option>
    <option value="sport">SPORT</option>
    <option value="tresurer">TRESURER</option>
    <option value="lady vice">LADY VICE</option>
    </select>
<br>
<br>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<input style="width:120px;background:purple;color:white;padding:12px;border-radius:4px;font-weight:bolder" type="submit" name="submit" value="SELECT">

        </form>
        <br>

<table>
<tr>
<td><p style="text-align:center"> <a href="votingpage.php"><input style="width:200px;padding:12px;border-radius:5px;background-color:purple;color:white;font-weight:bolder" type="button" value="VOTING PAGE" ></a> </p></td>
<td>  <p style="text-align:center"> <a href="index.php"><input style="width:200px;padding:12px;border-radius:5px;font-weight:bolder" type="button" value="LOGOUT" ></a> </p>
        </div>
        </td>

</td>
</div>

</div>
</div>

<br>
<br><br>

</body>
</html>