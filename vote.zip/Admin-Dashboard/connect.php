<?php
$conn = mysqli_connect("localhost","root","","futa_voting");

if(!$conn)
{
    echo "You are not connected to database";
}



?>