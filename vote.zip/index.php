<?php
include('connect.php');
?>

<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>Futa online voting | Homepage</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" type="text/css" media="screen" href="main.css" />
    <script src="main.js"></script>
</head>
<body>
    <br>
    <br>
  
    <div id="banner">
        <div class=" header">
       <div id="logo">
       <img style="float:left;height:100px;width:130px;margin-left:130px; margin-top:7px; border-radius:10px;" src="futo.jpg">
       </div>
       <div class="head">
       <h1>FEDERAL UNIVERSITY OF TECHNOLOGY AKURE </h1>
       </div>

            
        </div>
    <table>
        <tr>
            <td >
               <br><br><br>
               <h1>Welcome to FUTA online voting <br>registration portal</h1>
               
               <h2>  Please ensure you register in order for you to be qualified to vote for your favorite candidate</h2>
     </td>
            <td>
               <h3 style="text-align:center; color:white;">Already have a Voters account sign-in</h3>
                <div id="form">
                    <br>
                    <br> <br> <br>
                    <form method="post" action="index.php">
                        <label class="label">Voters ID: </label>
                    <input type="text" name="Matricno" class="input" placeholder="Enter your voters ID" required /><br><br> 
                    <label class="label">Password: </label>
                    <input type="password" name="password" class="input" placeholder="Enter your password" required /><br><br>
                    <input type="submit" class="submit" name="submit" value="Sign In" />
                    <h3 style="color:green"> <i> don't have an account please <a href="register.php">Register</a></i> </h3>

                </div>
            </td>
</tr>
</table>

<br><br><br>
<div class="footer">
           
   </div>

    </div>
    <?php
      session_start();
    if(isset($_POST['Matricno']))
    {
        $VotersID = mysqli_real_escape_string($conn, $_POST['Matricno']);
        $Password = mysqli_real_escape_string($conn, $_POST['password']);
        $sql = "SELECT * FROM voters_account WHERE Matricno = '$VotersID' and password = '$Password'";
        $result = mysqli_query($conn, $sql);
        if(mysqli_num_rows($result)==1)
        {
            $_SESSION['message'] = "You are now logged in";
            $_SESSION['Matricno'] = $VotersID;
            header("location:Election.php");
        }
        else{
            echo " <h2>Check your login credentials and try again </h2>";
        }
        
        

    }

?>


</body>
</html>