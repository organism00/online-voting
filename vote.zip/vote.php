<?php
session_start();
include("connect.php");
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>Election Page | FUTA</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" type="text/css" media="screen" href="main.css" />
    <script src="main.js"></script>
</head>
<body>
<?php echo 'Welcome'  .$_SESSION['Matricno'] ?>

<div id="voter-banner">
<div class="voter-header">
       <div id="voter-logo">
       <img style="float:left;height:90px;width:100px; margin-top:17px; border-radius:10px;" src="futo.jpg">
       </div>
       <div class="headings">
       <h3>FEDERAL UNIVERSITY OF TECHNOLOGY AKURE </h3>
       </div>
       <br><br> <br><br>
       <br><br><br>    
    
<?php
$POSITION = $_POST['position'];
$sql = "SELECT * FROM candidate WHERE position = '$POSITION'";
$result = mysqli_query($conn, $sql);


?>
  <table border="2" cellspacing="2" cellpadding="8">
                                    <tr>
                                        <th>FirstName</th>
                                    	<th>LastName</th>
                                    	<th>Sex</th>
                                    	<th>PhoneNo</th>
                                        <th>EmailAddress</th>
                                        <th>MatricNo</th>
                                    	<th>Department</th>
                                    	<th>GradeLevel</th>
                                    	<th>CGPA</th>
                                    	<th>Position Applying For</th>
<tr>
        <!-- php to fetch data from database-->

                                    <?php while($candidate = mysqli_fetch_assoc($result))
                                    {
                                        echo '<tr>';
                                        echo	'<td>'.$candidate['firstname'].'</td>';
                                        echo	'<td>'.$candidate['lastname'].'</td>';
                                        echo	'<td>'.$candidate['sex'].'</td>';
                                        echo	'<td>'.$candidate['phoneno'].'</td>';
                                        echo	'<td>'.$candidate['email'].'</td>';
                                        echo	'<td>'.$candidate['matricno'].'</td>';
                                        echo	'<td>'.$candidate['dept'].'</td>';
                                        echo	'<td>'.$candidate['gradelevel'].'</td>';
                                        echo	'<td>'.$candidate['cgpa'].'</td>';
                                        echo	'<td>'.$candidate['position'].'</td>';
                                        	
                                        echo '</tr>';
                                    }
                                    ?>
                                    </table>

                                </select>
                                    <br>
                                    <br><br><br><br><br><br><br><br>
                                    <br>
                             <p style="text-align:center">       <a href="Election.php"><input style="width:200px;padding:12px;border-radius:5px;background-color:purple;font-weight:bolder;color:white" type="button" value="BACK" ></a> </p>
</body>
</html>