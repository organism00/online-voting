<?php
session_start();
include("connect.php");
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>Election Page | FUTA</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" type="text/css" media="screen" href="main.css" />
    <script src="main.js"></script>
</head>
<body>
<?php echo 'Welcome'  .$_SESSION['Matricno'] ?>
<!--php code function -->

<div id="voter-banner">
<div class="voter-header">
       <div id="voter-logo">
       <img style="float:left;height:90px;width:100px; margin-top:17px; border-radius:10px;" src="futo.jpg">
       </div>
       <div class="headings">
       <h3>FEDERAL UNIVERSITY OF TECHNOLOGY AKURE </h3>
       </div>
       
       <br><br> <br><br>    
         
  <br><br>
  <form method="post" action="votingpage.php">
<table border="2" cellspacing="1" cellpadding="3">
    <tr>
        <td>
        <label>PRESIDENT</label>

    <select style="padding:7px;width:120px;border-radius:4px;" name="position">
    <?php
    $sql = "SELECT * FROM candidate";
$result = mysqli_query($conn, $sql);
while($row=mysqli_fetch_array($result))
{
    ?>
    <option value="president"><?php echo $row["firstname"], $row["lastname"]; ?></option>
    <?php
}
   ?>
    </select>

        </td>

        <td><label>VICE PRESIDENT</label>
   
    <select style="padding:7px;width:120px;border-radius:4px;" name="position">
    <?php
    $sql = "SELECT * FROM candidate";
$result = mysqli_query($conn, $sql);
while($row=mysqli_fetch_array($result))
{
    ?>
    <option value="vicepresident"><?php echo $row["firstname"], $row["lastname"]; ?></option>
    <?php
}
   ?>
    </select>

    </select>
    </td>
    <td><label>LADY VICE</label>
    <select style="padding:7px;width:120px;border-radius:4px;" name="position">
    <?php
    $sql = "SELECT * FROM candidate";
$result = mysqli_query($conn, $sql);
while($row=mysqli_fetch_array($result))
{
    ?>
    <option value="ladyvice"><?php echo $row["firstname"], $row["lastname"]; ?></option>
    <?php
}
   ?>
    </select>
    </td>

    <td><label>SECRETARY</label>
<select style="padding:7px;width:120px;border-radius:4px;" name="position">
    <?php
    $sql = "SELECT * FROM candidate";
$result = mysqli_query($conn, $sql);
while($row=mysqli_fetch_array($result))
{
    ?>
    <option value="secretary"><?php echo $row["firstname"], $row["lastname"]; ?></option>
    <?php
}
   ?>
    </select>
    </td>

    <td><label>TRESURER</label>
    <select style="padding:7px;width:120px;border-radius:4px;" name="position">
    <?php
    $sql = "SELECT * FROM candidate";
$result = mysqli_query($conn, $sql);
while($row=mysqli_fetch_array($result))
{
    ?>
    <option value="tresurer"><?php echo $row["firstname"], $row["lastname"]; ?></option>
    <?php
}
   ?>
    </select>
    </td>

    <td><label>PRO</label>
    <select style="padding:7px;width:120px;border-radius:4px;" name="position">
    <?php
    $sql = "SELECT * FROM candidate";
$result = mysqli_query($conn, $sql);
while($row=mysqli_fetch_array($result))
{
    ?>
    <option value="pro"><?php echo $row["firstname"], $row["lastname"]; ?></option>
    <?php
}
   ?>
    </select>
    </td>

    <td><label>SPORT</label>
  <select style="padding:7px;width:120px;border-radius:4px;" name="position">
    <?php
    $sql = "SELECT * FROM candidate";
$result = mysqli_query($conn, $sql);
while($row=mysqli_fetch_array($result))
{
    ?>
    <option value="sport"><?php echo $row["firstname"], $row["lastname"]; ?></option>
    <?php
}
   ?>
    </select>
    </td>

    <td><label>WELFARE</label>
    <select style="padding:7px;width:120px;border-radius:4px;" name="position">
    <?php
    $sql = "SELECT * FROM candidate";
$result = mysqli_query($conn, $sql);
while($row=mysqli_fetch_array($result))
{
    ?>
    <option value="welfare"><?php echo $row["firstname"], $row["lastname"]; ?></option>
    <?php
}
   ?>
    </select>
    </td>
    


</tr>
</table>
<br><br><br>
<input style="width:300px;padding:45px;margin-left:350px;background-color:yellow;font-weight:bolder;font-size:20px;border:4px solid red;" type="submit" name="submit" value="CAST YOUR VOTE">





</form>

<?php
if(isset($_POST['submit']))
{
$PRESIDENT = $_POST['president'];
$VICEPRESIDENT = $_POST['vicepresident'];
$LADYVICE = $_POST['ladyvice'];
$SECRETARY = $_POST['secretary'];
$WELFARE = $_POST['welfare'];
$PRO = $_POST['pro'];
$SPORT = $_POST['sport'];
$TRESURER = $_POST['tresurer'];

$query = "INSERT INTO result(president,vicepresident,ladyvice,secretary,welfare,pro,sport,tresurer) VALUES ('$PRESIDENT','$VICEPRESIDENT','$LADYVICE','$SECRETARY','$WELFARE','$PRO','$SPORT','$TRESURER')";
$result2 = mysqli_query($conn, $query);
if($result)
    {
        if(mysqli_affected_rows($conn)>0)
        {
            echo("Vote casted successful");
        }
        else{
            echo ("Error in voting");
        }
    }
}
?>
</div>
</div>




</body>
</html>